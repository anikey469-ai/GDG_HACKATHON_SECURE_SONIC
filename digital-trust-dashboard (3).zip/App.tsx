
import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import Header from './components/Header';
import VoiceForensics from './components/VoiceForensics';
import URLShield from './components/URLShield';
import { ForensicReport, DetectionResult, UrlScanResponse } from './types';

interface SessionLog {
  type: 'VOICE' | 'URL';
  timestamp: string;
  data: any;
}

const ForensicGraph = ({ report }: { report: ForensicReport | null }) => {
  const getPoints = () => {
    if (!report) return "M 0 60 Q 25 55 50 60 T 100 60 T 150 60 T 200 60";
    const isAi = report.classification === DetectionResult.AI;
    return isAi 
      ? "M 0 80 L 20 10 L 40 90 L 60 15 L 80 100 L 100 5 L 120 110 L 140 20 L 160 95 L 180 30 L 200 80"
      : "M 0 70 Q 30 60 60 75 T 120 65 T 180 72 T 200 70";
  };

  const color = report?.classification === DetectionResult.AI ? '#ef4444' : '#06b6d4';

  return (
    <div className={`glass-card p-8 rounded-[2rem] border transition-all duration-500 flex flex-col gap-4 overflow-hidden relative group ${report?.classification === DetectionResult.AI ? 'border-red-500/30' : 'border-white/10'}`}>
      <div className="flex justify-between items-center z-10">
        <div className="space-y-1">
          <span className={`text-[10px] font-mono uppercase tracking-[0.3em] font-black ${report?.classification === DetectionResult.AI ? 'text-red-500' : 'text-cyan-400'}`}>
            Spectral_Heuristics
          </span>
          <div className="text-[8px] font-mono text-white/30 uppercase tracking-widest">Signal_Phase: {report ? 'ANALYTIC_SYNC' : 'MONITORING'}</div>
        </div>
        <div className={`px-3 py-1 rounded-full bg-white/5 border text-[9px] font-mono uppercase ${report?.classification === DetectionResult.AI ? 'border-red-500/20 text-red-500' : 'border-white/10 text-white/40'}`}>
          VOICE_BAND_RT
        </div>
      </div>

      <div className="h-40 w-full relative mt-4">
        <svg viewBox="0 0 200 120" className={`w-full h-full drop-shadow-[0_0_15px_${report?.classification === DetectionResult.AI ? 'rgba(239,68,68,0.3)' : 'rgba(0,255,255,0.3)'}]`}>
          <defs>
            <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.4" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="1.5" result="coloredBlur"/>
              <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>
          <g className="opacity-10" stroke="white" strokeWidth="0.2">
            {[...Array(10)].map((_, i) => <line key={i} x1="0" y1={i * 12} x2="200" y2={i * 12} />)}
            {[...Array(10)].map((_, i) => <line key={i} x1={i * 20} y1="0" x2={i * 20} y2="120" />)}
          </g>
          <motion.path initial={{ d: "M 0 60 Q 50 60 100 60 T 200 60" }} animate={{ d: getPoints() }} fill="url(#areaGradient)" transition={{ duration: 1, ease: "anticipate" }} />
          <motion.path initial={{ d: "M 0 60 Q 50 60 100 60 T 200 60" }} animate={{ d: getPoints() }} fill="none" stroke={color} strokeWidth="1.5" filter="url(#glow)" transition={{ duration: 1, ease: "anticipate" }} />
          <motion.rect animate={{ x: [0, 200] }} transition={{ duration: 3, repeat: Infinity, ease: "linear" }} width="1" height="120" fill={color} className="opacity-20" />
        </svg>
      </div>

      <div className="flex justify-between items-center mt-2 z-10">
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <div className={`w-1.5 h-1.5 rounded-full ${report ? 'animate-ping' : ''}`} style={{ backgroundColor: color }}></div>
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Signal_Lock</span>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-1.5 h-1.5 rounded-full ${report?.classification === DetectionResult.AI ? 'bg-red-500' : 'bg-gray-700'}`}></div>
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Artifact_Scan</span>
          </div>
        </div>
        <span className="text-[9px] font-mono text-gray-600">FRQ_RNG: 85Hz - 8kHz</span>
      </div>
    </div>
  );
};

const ThreatMonitor = ({ lastReport }: { lastReport: ForensicReport | null }) => {
  const stats = [
    { label: 'Synthetic Drift', value: lastReport ? `${(Math.random() * 5).toFixed(2)}%` : '0.12%', color: 'text-white' },
    { label: 'Integrity Score', value: lastReport ? `${lastReport.humanProbability}%` : '---', color: lastReport ? (lastReport.classification === DetectionResult.HUMAN ? 'text-green-400' : 'text-red-500') : 'text-gray-700' },
    { label: 'Response Latency', value: lastReport ? '14ms' : '0ms', color: 'text-cyan-400' },
    { label: 'Anomaly Status', value: lastReport ? (lastReport.classification === DetectionResult.AI ? 'CRITICAL' : 'SECURE') : 'IDLE', color: lastReport?.classification === DetectionResult.AI ? 'text-red-500' : 'text-cyan-400' }
  ];

  return (
    <div className={`glass-card p-8 rounded-[2rem] border transition-all duration-700 ${
      lastReport?.classification === DetectionResult.AI ? 'border-red-500/30 bg-red-500/5' : 'border-white/10'
    }`}>
      <h3 className="text-[10px] font-mono text-cyan-400 mb-8 flex items-center justify-between font-black tracking-[0.3em]">
        <span className="flex items-center gap-3">
          <span className={`w-2 h-2 rounded-full animate-pulse ${lastReport?.classification === DetectionResult.AI ? 'bg-red-500 shadow-[0_0_10px_#ef4444]' : 'bg-cyan-500 shadow-[0_0_10px_#06b6d4]'}`}></span>
          SYSTEM_TELEMETRY
        </span>
        <span className="text-[9px] opacity-40 uppercase tracking-tighter">NODE_ID: TR-09</span>
      </h3>
      <div className="grid grid-cols-2 gap-x-8 gap-y-6">
        {stats.map((stat, i) => (
          <div key={i} className="flex flex-col border-l border-white/5 pl-4 group hover:border-cyan-500/30 transition-colors">
            <span className="text-[9px] text-gray-500 font-mono uppercase tracking-[0.2em] mb-1">{stat.label}</span>
            <span className={`text-xl font-black font-mono tracking-tighter ${stat.color}`}>{stat.value}</span>
          </div>
        ))}
      </div>
      <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
         <span className="text-[8px] font-mono text-gray-600 uppercase">Heuristic engine v2.0.1</span>
         <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className={`w-1 h-3 rounded-full ${lastReport ? (lastReport.classification === DetectionResult.AI ? 'bg-red-500/40' : 'bg-cyan-500/40') : 'bg-white/5'}`}></div>
            ))}
         </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [lastReport, setLastReport] = useState<ForensicReport | null>(null);
  const [sessionHistory, setSessionHistory] = useState<SessionLog[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  const [resetKey, setResetKey] = useState(0);

  const addToHistory = useCallback((type: 'VOICE' | 'URL', data: any) => {
    setSessionHistory(prev => [...prev, { type, data, timestamp: new Date().toISOString() }]);
  }, []);

  const handleVoiceComplete = (report: ForensicReport) => {
    setLastReport(report);
    addToHistory('VOICE', report);
  };

  const handleUrlComplete = (res: UrlScanResponse) => {
    addToHistory('URL', res);
  };

  const resetAll = useCallback(() => {
    // Protocol reset forces unmount and remount of all keyed sub-components
    setLastReport(null);
    setSessionHistory([]);
    setResetKey(prev => prev + 1);
    console.log("SYSTEM_WIPE: OK");
  }, []);

  const exportSessionAudit = () => {
    if (sessionHistory.length === 0) return;
    setIsExporting(true);
    setTimeout(() => {
      let reportContent = `# TRUST AUDIT - SESSION LOG\nGenerated: ${new Date().toLocaleString()}\n\n`;
      sessionHistory.forEach((log, idx) => {
        reportContent += `## ENTRY #${idx + 1} [${log.type}]\nTimestamp: ${log.timestamp}\n`;
        if (log.type === 'VOICE') {
          const d = log.data as ForensicReport;
          reportContent += `Class: ${d.classification} | Confidence: ${d.confidence}%\nDetails: ${d.technicalDetails}\n`;
        } else {
          const d = log.data as UrlScanResponse;
          reportContent += `Status: ${d.isMalicious ? 'MALICIOUS' : 'SAFE'}\nAnalysis: ${d.analysis}\n`;
        }
        reportContent += `\n`;
      });
      const element = document.createElement("a");
      const file = new Blob([reportContent], { type: 'text/markdown' });
      element.href = URL.createObjectURL(file);
      element.download = `Trust_Audit_${Date.now()}.md`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      setIsExporting(false);
    }, 800);
  };

  return (
    <div className="min-h-screen pb-32 selection:bg-cyan-500/30">
      <Header onGlobalReset={resetAll} />
      <main className="max-w-7xl mx-auto px-6 mt-16 md:mt-24 space-y-16">
        <section className="flex flex-col md:flex-row md:items-end justify-between gap-12 mb-12">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-[9px] font-mono text-cyan-400 uppercase tracking-widest font-bold">Protocol v2.5.8 Alpha</span>
              <span className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-ping"></span>
            </div>
            <h2 className="text-5xl md:text-8xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-b from-white to-white/40 leading-[0.9] uppercase">Trust Audit <br className="hidden md:block" /> Engine.</h2>
          </motion.div>
        </section>

        <div className="grid grid-cols-1 gap-12">
          <VoiceForensics key={`voice-${resetKey}`} onAnalysisComplete={handleVoiceComplete} />
          <URLShield key={`url-${resetKey}`} onScanComplete={handleUrlComplete} />
        </div>

        <section className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ThreatMonitor lastReport={lastReport} />
            <ForensicGraph report={lastReport} />
          </div>
        </section>
      </main>

      <footer className="mt-32 border-t border-white/5 py-16">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
           <span className="text-[11px] font-mono text-gray-600 uppercase">© 2024 DIGITAL TRUST ENGINE</span>
           <button 
             onClick={exportSessionAudit} 
             disabled={isExporting}
             className="text-[10px] font-mono text-gray-500 hover:text-cyan-400 uppercase tracking-widest border border-white/5 px-8 py-3 rounded-xl disabled:opacity-30"
           >
             {isExporting ? 'EXPORTING...' : 'GENERATE EXPORT'}
           </button>
        </div>
      </footer>
    </div>
  );
};

export default App;
