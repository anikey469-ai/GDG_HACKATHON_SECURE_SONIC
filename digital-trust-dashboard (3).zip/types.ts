
export enum AnalysisStatus {
  IDLE = 'IDLE',
  RECORDING = 'RECORDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export enum DetectionResult {
  HUMAN = 'HUMAN',
  AI = 'AI',
  UNKNOWN = 'UNKNOWN'
}

export interface AudioFeatures {
  pitch: number;
  zcr: number;
  mfccs: number[];
  spectralRolloff: number;
  humanProbability: number;
}

export interface ForensicReport {
  classification: DetectionResult;
  confidence: number;
  humanProbability: number;
  summary: string;
  technicalDetails: string;
  features: AudioFeatures;
  timestamp: string;
}

export interface WebRiskResult {
  url: string;
  status: 'SAFE' | 'MALICIOUS' | 'UNKNONWN';
  threatTypes: string[];
}

// Added UrlScanResponse interface to centralize types and fix App.tsx import error
export interface UrlScanResponse {
  analysis: string;
  isMalicious: boolean;
  groundingUrls?: { uri: string; title: string }[];
}
