
import { GoogleGenAI, Type } from "@google/genai";
import { DetectionResult, AudioFeatures, UrlScanResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateForensicReport = async (
  features: AudioFeatures,
  classification: DetectionResult,
  confidence: number
): Promise<string> => {
  const systemInstruction = `
    You are an Elite Audio Forensic Investigator.
    TECHNICAL MARKERS:
    - Pitch Std (P) > 340: AI High Frequency instability.
    - ZCR Var (Z) > 0.015: Synthetic high-frequency noise.
    - Timbre Var (M) < 700 or > 2100: Synthetic "too clean" or "digital mess" signatures.
    - Rolloff (R) > 4800: Digital shimmer/clipping.
    
    TASK: Briefly justify ${classification} based on these specific metrics. Focus on the stability/chaos balance.
    OUTPUT: Max 25 words. Very technical.
  `;

  const prompt = `
    TELEMETRY:
    P_STD: ${features.pitch.toFixed(1)}
    Z_VAR: ${features.zcr.toFixed(4)}
    M_VAR: ${features.mfccs[0].toFixed(1)}
    R_AVG: ${features.spectralRolloff.toFixed(1)}
    RESULT: ${classification}
    PROB: ${features.humanProbability}%
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.1,
      },
    });

    return response.text?.trim() || "DIAG_INCOMPLETE";
  } catch (error) {
    console.error("Forensic Hub Error:", error);
    return "NODE_OFFLINE";
  }
};

export const scanUrlThreat = async (url: string): Promise<UrlScanResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `TARGET_URL: ${url}`,
      config: {
        systemInstruction: `
          You are a Cyber Sentinel. Detect malicious URL patterns, phishing, or keyboard walks.
          OUTPUT_RULE: Keep analysis HIGHLY COMPACT (Max 15 words).
          CLASSIFICATION: Must clearly state if the site is SAFE or MALICIOUS.
          Use cold, professional terminology.
        `,
        tools: [{ googleSearch: {} }]
      }
    });

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const urls = groundingChunks?.map((chunk: any) => ({
      uri: chunk.web?.uri,
      title: chunk.web?.title
    })).filter((u: any) => u.uri && u.title);

    const text = response.text?.trim() || "INTEL_UNAVAILABLE";
    
    // Malicious detection logic based on keywords in the compact report
    const maliciousKeywords = ['malicious', 'phishing', 'threat', 'unsafe', 'suspicious', 'keyboard walk', 'dga', 'danger', 'unwanted', 'malware'];
    const isMalicious = maliciousKeywords.some(keyword => text.toLowerCase().includes(keyword));

    return {
      analysis: text,
      isMalicious,
      groundingUrls: urls
    };
  } catch (error) {
    console.error("URL Shield Error:", error);
    return {
      analysis: "SCAN_INTERRUPTED",
      isMalicious: false
    };
  }
};
