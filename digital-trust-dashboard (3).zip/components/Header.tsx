
import React from 'react';

interface HeaderProps {
  onGlobalReset?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onGlobalReset }) => {
  return (
    <header className="border-b border-white/10 bg-[#050505]/80 backdrop-blur-2xl sticky top-0 z-50">
      <div className="max-w-screen-2xl mx-auto px-6 md:px-10 h-24 flex items-center justify-between">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="absolute inset-0 bg-cyan-500 blur-2xl opacity-10 pointer-events-none"></div>
            <div className="relative w-10 h-10 md:w-12 md:h-12 bg-black border border-white/10 flex items-center justify-center rounded-xl overflow-hidden group">
              <div className="absolute inset-0 bg-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="glow-text-cyan md:w-6 md:h-6"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            </div>
          </div>
          <div className="hidden sm:block">
            <h1 className="font-black text-sm md:text-xl tracking-tighter glow-text-cyan uppercase">Digital_Trust_Engine</h1>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 bg-cyan-500 rounded-full animate-pulse"></div>
              <span className="text-[8px] md:text-[9px] font-mono text-cyan-400/60 uppercase tracking-[0.2em]">Cyber Defense Node: Elite-v2</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 md:gap-8">
          <button 
            onClick={onGlobalReset}
            type="button"
            className="group relative flex items-center gap-2 px-3 md:px-5 py-2 border border-red-500/40 text-red-500 hover:bg-red-500/10 rounded-lg transition-all shadow-[0_0_15px_rgba(239,68,68,0.1)] active:scale-95 overflow-hidden cursor-pointer"
          >
            <div className="absolute inset-0 bg-red-500/5 animate-pulse group-hover:bg-red-500/20 pointer-events-none"></div>
            <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping pointer-events-none"></div>
            <span className="relative text-[9px] md:text-[10px] font-mono tracking-[0.2em] uppercase font-black">
              [ FULL_SYSTEM_WIPE ]
            </span>
          </button>

          <div className="hidden lg:flex items-center gap-6 border-l border-white/10 pl-8">
            {['COMMAND', 'INTEL', 'SPECTRAL'].map((item, idx) => (
              <a key={item} href="#" className={`text-[10px] font-mono tracking-widest hover:text-cyan-400 transition-all ${idx === 0 ? 'text-white border-b border-cyan-500 pb-1' : 'text-gray-500'}`}>
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-4 md:gap-6 border-l border-white/10 pl-4 md:pl-6">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-[7px] md:text-[8px] font-mono text-gray-600 uppercase">Integrity</span>
              <span className="text-[9px] md:text-[10px] font-mono text-cyan-400 font-bold">NOMINAL</span>
            </div>
            <div className="w-8 h-8 md:w-10 md:h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group hover:border-cyan-500/50 transition-all cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400 group-hover:text-white md:w-5 md:h-5"><path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"/><path d="M12 10m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"/><path d="M6.168 18.849a4 4 0 0 1 3.832 -2.849h4a4 4 0 0 1 3.834 2.855"/></svg>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
