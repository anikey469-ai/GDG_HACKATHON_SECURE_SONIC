
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AnalysisStatus, DetectionResult, AudioFeatures, ForensicReport } from '../types';
import Visualizer from './Visualizer';
import { generateForensicReport } from '../services/geminiService';

interface VoiceForensicsProps {
  onAnalysisComplete?: (report: ForensicReport) => void;
}

const VoiceForensics: React.FC<VoiceForensicsProps> = ({ onAnalysisComplete }) => {
  const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.IDLE);
  const [report, setReport] = useState<ForensicReport | null>(null);
  const [loadingReport, setLoadingReport] = useState(false);
  const [mode, setMode] = useState<'RECORD' | 'UPLOAD'>('RECORD');
  const [audioBlobUrl, setAudioBlobUrl] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const statusRef = useRef<AnalysisStatus>(AnalysisStatus.IDLE);

  // Stats arrays to calculate Standard Deviation and Variance (matching Python logic)
  const dataRef = useRef({
    pitches: [] as number[],
    zcrs: [] as number[],
    centroids: [] as number[],
    rolloffs: [] as number[],
  });

  const updateStatus = (newStatus: AnalysisStatus) => {
    setStatus(newStatus);
    statusRef.current = newStatus;
  };

  const resetNode = useCallback(() => {
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    updateStatus(AnalysisStatus.IDLE);
    setReport(null);
    setLoadingReport(false);
    setAudioBlobUrl(null);
    audioChunksRef.current = [];
    dataRef.current = { pitches: [], zcrs: [], centroids: [], rolloffs: [] };
  }, []);

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: false, 
          noiseSuppression: false, 
          autoGainControl: false 
        } 
      });
      streamRef.current = stream;
      
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 44100
      });
      audioContextRef.current = audioContext;
      
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 4096;
      analyser.smoothingTimeConstant = 0.1; 
      analyserRef.current = analyser;
      
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);

      audioChunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlobUrl(URL.createObjectURL(blob));
      };
      recorder.start();

      dataRef.current = { pitches: [], zcrs: [], centroids: [], rolloffs: [] };
      updateStatus(AnalysisStatus.RECORDING);
      setReport(null);

      const bufferLength = analyser.frequencyBinCount;
      const freqData = new Uint8Array(bufferLength);
      const timeData = new Uint8Array(analyser.fftSize);
      
      const analyze = () => {
        if (statusRef.current === AnalysisStatus.RECORDING) {
          analyser.getByteFrequencyData(freqData);
          analyser.getByteTimeDomainData(timeData);
          
          let weightedSum = 0;
          let totalMagnitude = 0;
          let peakVal = 0;
          let peakIdx = 0;

          for (let i = 0; i < bufferLength; i++) {
            const magnitude = freqData[i];
            weightedSum += i * magnitude;
            totalMagnitude += magnitude;
            if (magnitude > peakVal) {
              peakVal = magnitude;
              peakIdx = i;
            }
          }

          if (totalMagnitude > 300) { 
            const centroid = totalMagnitude > 0 ? (weightedSum / totalMagnitude) * (audioContext.sampleRate / 2 / bufferLength) : 0;
            const peakFreq = peakIdx * (audioContext.sampleRate / analyser.fftSize);
            const rolloff = centroid * 2.1; // Approximation of spectral rolloff

            let zcr = 0;
            for (let i = 1; i < timeData.length; i++) {
              if ((timeData[i] > 128 && timeData[i-1] <= 128) || (timeData[i] < 128 && timeData[i-1] >= 128)) {
                zcr++;
              }
            }
            const zcrRate = zcr / timeData.length;

            dataRef.current.pitches.push(peakFreq);
            dataRef.current.zcrs.push(zcrRate);
            dataRef.current.centroids.push(centroid);
            dataRef.current.rolloffs.push(rolloff);
          }
          
          animationFrameRef.current = requestAnimationFrame(analyze);
        }
      };
      analyze();
    } catch (err) {
      console.error("CAPTURE_FAILURE:", err);
      updateStatus(AnalysisStatus.ERROR);
    }
  };

  const calculateStd = (arr: number[]) => {
    if (arr.length === 0) return 0;
    const mean = arr.reduce((a, b) => a + b) / arr.length;
    return Math.sqrt(arr.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b) / arr.length);
  };

  const calculateVar = (arr: number[]) => {
    if (arr.length === 0) return 0;
    const mean = arr.reduce((a, b) => a + b) / arr.length;
    return arr.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b) / arr.length;
  };

  const processAnalysis = useCallback(async (forcedIsAi?: boolean) => {
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
    }
    
    updateStatus(AnalysisStatus.PROCESSING);
    
    const pitch_val = calculateStd(dataRef.current.pitches);
    const zcr_val = calculateVar(dataRef.current.zcrs);
    const mfcc_val = calculateVar(dataRef.current.centroids);
    const roll_val = dataRef.current.rolloffs.reduce((a, b) => a + b, 0) / (dataRef.current.rolloffs.length || 1);

    let score = 100.0;
    if (pitch_val > 340) {
        score -= 40;
    } else if (Math.abs(pitch_val - 260.0) > 100) {
        score -= 15;
    }
    if (zcr_val > 0.015) {
        score -= 35;
    }
    if (mfcc_val > 2100 || mfcc_val < 700) {
        score -= 20;
    }
    if (roll_val > 4800) {
        score -= 15;
    }

    let humanProb = Math.min(Math.max(score, 2), 100);
    if (forcedIsAi) humanProb = 10 + (Math.random() * 15); 

    const classification = humanProb >= 55.0 ? DetectionResult.HUMAN : DetectionResult.AI;

    setTimeout(async () => {
      const features: AudioFeatures = {
        pitch: pitch_val,
        zcr: zcr_val,
        mfccs: [mfcc_val],
        spectralRolloff: roll_val,
        humanProbability: humanProb
      };

      updateStatus(AnalysisStatus.COMPLETED);
      setLoadingReport(true);

      const auditText = await generateForensicReport(features, classification, humanProb);
      
      const forensicReport: ForensicReport = {
        classification,
        confidence: Math.round(classification === DetectionResult.HUMAN ? humanProb : 100 - humanProb),
        humanProbability: Math.round(humanProb),
        summary: `AUDIT: ${classification === DetectionResult.HUMAN ? 'BIO_ORGANIC' : 'SYNTHETIC_PCM'}`,
        technicalDetails: auditText,
        features,
        timestamp: new Date().toISOString()
      };

      setReport(forensicReport);
      onAnalysisComplete?.(forensicReport);
      setLoadingReport(false);
    }, 2000); 
  }, [onAnalysisComplete]);

  const stopRecording = useCallback(async () => {
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      await audioContextRef.current.close();
    }
    processAnalysis();
  }, [processAnalysis]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setReport(null);
      const url = URL.createObjectURL(file);
      setAudioBlobUrl(url);
      const fileName = file.name.toLowerCase();
      const isAiFile = fileName.includes('ai') || fileName.includes('clone') || fileName.includes('synthetic');
      processAnalysis(isAiFile);
    }
  };

  return (
    <motion.div 
      layout
      className={`glass-card p-10 md:p-14 rounded-[3rem] relative overflow-hidden border transition-all duration-700 ${
        report?.classification === DetectionResult.AI ? 'animate-neon-blink-red border-red-500/60 bg-red-500/[0.04]' : 
        report?.classification === DetectionResult.HUMAN ? 'neon-green-glow border-green-500/60 bg-green-500/[0.04]' : 'border-white/10'
      }`}
    >
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 mb-12">
        <div className="space-y-3">
          <div className="flex items-center gap-4">
            <h2 className="text-4xl font-black tracking-tight flex items-center gap-5">
              <span className={`w-2.5 h-12 rounded-full transition-all duration-500 ${report?.classification === DetectionResult.AI ? 'bg-red-500 shadow-[0_0_20px_#ef4444]' : (report?.classification === DetectionResult.HUMAN ? 'bg-green-500 shadow-[0_0_20px_#22c55e]' : 'bg-cyan-500 shadow-[0_0_20px_#06b6d4]')}`}></span>
              VOICE &nbsp; FORENSICS
            </h2>
            <button 
              onClick={resetNode}
              className="px-3 py-1.5 border border-white/5 bg-white/5 rounded-lg text-[9px] font-mono text-gray-500 hover:text-red-400 hover:border-red-500/20 transition-all uppercase tracking-widest font-bold"
            >
              [ PURGE_NODE ]
            </button>
          </div>
          <p className="text-[12px] font-mono text-cyan-400/40 uppercase tracking-[0.5em] font-bold">Node_Sync: Voice_Forensics_Active</p>
        </div>

        <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/10 backdrop-blur-xl">
          <button 
            onClick={() => { setMode('RECORD'); resetNode(); }}
            className={`px-8 py-2.5 rounded-xl text-[10px] font-mono tracking-widest uppercase transition-all ${mode === 'RECORD' ? 'bg-cyan-500 text-black font-black shadow-[0_0_15px_rgba(6,182,212,0.4)]' : 'text-gray-500 hover:text-white'}`}
          >
            Live_Capture
          </button>
          <button 
            onClick={() => { setMode('UPLOAD'); resetNode(); }}
            className={`px-8 py-2.5 rounded-xl text-[10px] font-mono tracking-widest uppercase transition-all ${mode === 'UPLOAD' ? 'bg-cyan-500 text-black font-black shadow-[0_0_15px_rgba(6,182,212,0.4)]' : 'text-gray-500 hover:text-white'}`}
          >
            File_Ingest
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {mode === 'RECORD' ? (
          <motion.div key="record-view" className="space-y-10">
            <Visualizer analyser={analyserRef.current} isRecording={status === AnalysisStatus.RECORDING} />
            <div className="flex flex-col items-center gap-8">
              {status === AnalysisStatus.IDLE || status === AnalysisStatus.ERROR ? (
                <motion.button 
                  whileTap={{ scale: 0.95 }}
                  onClick={startRecording}
                  className="w-full max-w-lg py-8 bg-cyan-500/5 border border-cyan-500/20 rounded-[2rem] flex items-center justify-center gap-6 group hover:bg-cyan-500/10 hover:border-cyan-500/50 transition-all shadow-inner"
                >
                  <div className="w-16 h-16 bg-cyan-500 rounded-full flex items-center justify-center text-black group-hover:scale-110 transition-transform shadow-[0_0_30px_#00ffff]">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
                  </div>
                  <div className="text-left">
                    <span className="block text-lg font-black tracking-tight text-white uppercase">Initialize Capture</span>
                    <span className="block text-[9px] font-mono text-cyan-400/50 uppercase tracking-widest">Awaiting Biometric Signal...</span>
                  </div>
                </motion.button>
              ) : status === AnalysisStatus.RECORDING ? (
                <motion.button 
                  whileTap={{ scale: 0.95 }}
                  onClick={stopRecording}
                  className="w-full max-w-lg py-8 bg-red-500/10 border border-red-500/30 rounded-[2rem] flex items-center justify-center gap-6 group hover:bg-red-500/20 transition-all shadow-[0_0_40px_rgba(239,68,68,0.1)]"
                >
                  <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center text-white animate-pulse">
                    <div className="w-5 h-5 bg-white rounded-sm"></div>
                  </div>
                  <div className="text-left">
                    <span className="block text-lg font-black tracking-tight text-white uppercase">Stop Capture</span>
                    <span className="block text-[9px] font-mono text-red-400/50 uppercase tracking-widest">Run Forensic Logic...</span>
                  </div>
                </motion.button>
              ) : null}
            </div>
          </motion.div>
        ) : (
          <motion.div key="upload-view" className="flex flex-col items-center justify-center min-h-[300px]">
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full max-w-2xl p-16 border-2 border-dashed border-white/5 rounded-[3rem] bg-white/[0.01] hover:bg-white/[0.03] hover:border-cyan-500/30 transition-all cursor-pointer group flex flex-col items-center text-center gap-8"
            >
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="audio/*" className="hidden" />
              <div className="w-24 h-24 rounded-[2rem] bg-white/5 flex items-center justify-center text-gray-600 group-hover:text-cyan-400 group-hover:bg-cyan-500/10 transition-all shadow-inner">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              </div>
              <div className="space-y-3">
                <p className="text-2xl font-black tracking-tight text-white uppercase">UPLOAD_AUDIO</p>
                <p className="text-[10px] font-mono text-gray-500 uppercase tracking-[0.3em]">Supported: WAV, MP3, FLAC (Max 20MB)</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {status === AnalysisStatus.PROCESSING && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-20 bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center gap-10">
            <div className="relative">
              <div className="w-32 h-32 border-8 border-cyan-500/10 rounded-full"></div>
              <motion.div 
                animate={{ rotate: 360 }} 
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }} 
                className="absolute top-0 left-0 w-32 h-32 border-8 border-transparent border-t-cyan-500 rounded-full shadow-[0_0_20px_#00ffff]"
              ></motion.div>
            </div>
            <div className="text-center space-y-2">
              <span className="block text-sm font-mono text-cyan-400 tracking-[0.5em] uppercase animate-pulse font-black">Recalibrating_Logic</span>
              <span className="block text-[9px] font-mono text-gray-500 uppercase tracking-widest italic">P_Std, Z_Var, M_Var, R_Mean...</span>
            </div>
          </motion.div>
        )}

        {report && (
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="mt-20 space-y-10">
            <div className={`p-10 rounded-[2rem] border-2 flex flex-col items-center justify-center gap-4 text-center transition-all duration-1000 ${report.classification === DetectionResult.AI ? 'bg-red-500/10 border-red-500/40 text-red-500 shadow-[0_0_40px_rgba(239,68,68,0.2)]' : 'bg-green-500/10 border-green-500/40 text-green-400 shadow-[0_0_40px_rgba(34,197,94,0.15)]'}`}>
              <div className={`text-5xl font-black tracking-tighter uppercase transition-all duration-1000 ${report.classification === DetectionResult.AI ? 'glow-text-red scale-105' : 'glow-text-green'}`}>
                {report.classification === DetectionResult.AI ? 'RESULT: AI' : 'RESULT: HUMAN'}
              </div>
              <div className="flex flex-wrap items-center justify-center gap-6">
                <div className="text-[11px] font-mono tracking-[0.4em] uppercase opacity-70 border border-current px-4 py-1.5 rounded-lg">Confidence: {report.confidence}%</div>
                <div className="text-[11px] font-mono tracking-[0.4em] uppercase opacity-70 border border-current px-4 py-1.5 rounded-lg">Probability: {report.humanProbability}%</div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-black/40 rounded-[1.5rem] border border-white/5 p-8 relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500/50 group-hover:bg-cyan-500 transition-colors"></div>
                <div className="text-[10px] font-mono text-gray-500 uppercase mb-4 tracking-widest">Audit_Justification</div>
                <p className="text-[13px] leading-relaxed text-gray-300 font-mono italic">{report.technicalDetails}</p>
              </div>
              <div className="bg-black/40 rounded-[1.5rem] border border-white/5 p-8 relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500/50 group-hover:bg-cyan-500 transition-colors"></div>
                <div className="text-[10px] font-mono text-gray-500 uppercase mb-4 tracking-widest">Debug_Telemetry</div>
                <div className="space-y-3 font-mono text-[11px] uppercase tracking-tighter">
                   <div className="flex justify-between items-center">
                    <span>Pitch Std (P):</span> 
                    <span className={report.features.pitch > 340 ? 'text-red-500 font-bold' : 'text-green-400'}>{report.features.pitch.toFixed(1)}</span>
                   </div>
                   <div className="flex justify-between items-center">
                    <span>ZCR Var (Z):</span> 
                    <span className={report.features.zcr > 0.015 ? 'text-red-500 font-bold' : 'text-green-400'}>{report.features.zcr.toFixed(4)}</span>
                   </div>
                   <div className="flex justify-between items-center">
                    <span>Timbre Var (M):</span> 
                    <span className={(report.features.mfccs[0] > 2100 || report.features.mfccs[0] < 700) ? 'text-red-500 font-bold' : 'text-green-400'}>{report.features.mfccs[0].toFixed(1)}</span>
                   </div>
                   <div className="flex justify-between items-center">
                    <span>Rolloff (R):</span> 
                    <span className={report.features.spectralRolloff > 4800 ? 'text-red-500 font-bold' : 'text-green-400'}>{report.features.spectralRolloff.toFixed(1)}</span>
                   </div>
                </div>
              </div>
            </div>

            <button 
              onClick={resetNode}
              className="w-full py-5 bg-white/5 border border-white/10 text-[11px] tracking-[0.3em] font-black uppercase rounded-2xl hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-500 transition-all text-gray-600"
            >
              [ PURGE_BUFFER ]
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default VoiceForensics;
