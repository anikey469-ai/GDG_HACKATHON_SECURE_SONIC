
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { scanUrlThreat } from '../services/geminiService';
import { UrlScanResponse } from '../types';

interface URLShieldProps {
  onScanComplete?: (result: UrlScanResponse) => void;
}

const URLShield: React.FC<URLShieldProps> = ({ onScanComplete }) => {
  const [url, setUrl] = useState('');
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<UrlScanResponse | null>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    
    setScanning(true);
    setResult(null);
    
    const scanResponse = await scanUrlThreat(url);
    setResult(scanResponse);
    onScanComplete?.(scanResponse);
    setScanning(false);
  };

  const clearResult = () => {
    setResult(null);
    setUrl('');
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className={`glass-card p-10 rounded-3xl transition-all duration-700 ${
        result?.isMalicious ? 'animate-neon-blink-red border-red-500/60' : 
        result ? 'neon-green-glow border-green-500/60 bg-green-500/[0.02]' : 'border-white/10'
      }`}
    >
      <div className="mb-8 space-y-1">
        <h2 className="text-2xl font-black tracking-tight flex items-center gap-3">
          <span className={`w-1.5 h-8 rounded-full transition-all duration-500 ${
            result?.isMalicious ? 'bg-red-500 shadow-[0_0_15px_#ff0033]' : 
            result ? 'bg-green-500 shadow-[0_0_15px_#22c55e]' : 'bg-cyan-500 shadow-[0_0_10px_rgba(0,255,255,0.8)]'
          }`}></span>
          URL SHIELD
        </h2>
        <p className="text-[10px] font-mono text-cyan-400/40 uppercase tracking-widest font-bold">Threat_Pattern_Sentinel_v2</p>
      </div>

      <form onSubmit={handleScan} className="relative mb-8 flex gap-4">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" /></svg>
          </div>
          <input 
            type="text" 
            placeholder="ENTER_DOMAIN_OR_URL_FOR_AUDIT" 
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-2xl py-5 pl-12 pr-4 focus:outline-none focus:border-cyan-500/50 transition-all font-mono text-sm tracking-wide text-cyan-50"
          />
        </div>
        
        <div className="flex gap-2">
           <button 
            type="submit"
            disabled={scanning}
            className="px-8 bg-cyan-500 text-black font-black rounded-xl transition-all text-[10px] tracking-widest uppercase disabled:opacity-30 shadow-[0_0_20px_rgba(0,255,255,0.2)] hover:shadow-[0_0_30px_rgba(0,255,255,0.4)]"
          >
            {scanning ? 'SCANNING...' : 'INIT_SCAN'}
          </button>
          <button 
            type="button"
            onClick={clearResult}
            className="px-6 bg-white/5 border border-white/10 text-gray-500 hover:text-red-500 hover:border-red-500/40 rounded-xl transition-all text-[10px] tracking-widest uppercase font-black"
          >
            RESET
          </button>
        </div>
      </form>

      <AnimatePresence>
        {result && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className={`p-4 rounded-xl flex items-center justify-between border ${
              result.isMalicious 
                ? 'bg-red-500/10 border-red-500/40 text-red-500 shadow-[0_0_20px_rgba(239,68,68,0.1)]' 
                : 'bg-green-500/10 border-green-500/40 text-green-400 shadow-[0_0_20px_rgba(34,197,94,0.1)]'
            }`}>
              <div className="flex items-center gap-3">
                 <div className={`w-3 h-3 rounded-full ${result.isMalicious ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}></div>
                 <span className="font-black tracking-[0.3em] text-[12px] uppercase">
                   {result.isMalicious ? 'THREAT_ALERT' : 'VERIFIED_SAFE'}
                 </span>
              </div>
              <span className="text-[9px] font-mono opacity-50 uppercase tracking-tighter">Heuristic_Audit_Complete</span>
            </div>

            <div className="bg-black/40 p-6 rounded-xl border border-white/5 relative group">
               <div className="absolute top-2 right-4 text-[7px] font-mono text-white/10 uppercase tracking-[0.5em]">Compact_Audit</div>
               <div className="text-gray-300 font-mono text-[13px] leading-relaxed uppercase tracking-tight">
                 {result.analysis}
               </div>

               {result.groundingUrls && result.groundingUrls.length > 0 && (
                 <div className="mt-4 pt-4 border-t border-white/5">
                   <div className="flex flex-wrap gap-2">
                     {result.groundingUrls.map((source, i) => (
                       <a 
                         key={i} 
                         href={source.uri} 
                         target="_blank" 
                         rel="noopener noreferrer"
                         className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-[9px] text-gray-500 hover:text-cyan-400 hover:border-cyan-500/50 transition-all truncate max-w-[250px]"
                       >
                         SOURCE_{i+1}: {source.title}
                       </a>
                     ))}
                   </div>
                 </div>
               )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default URLShield;
