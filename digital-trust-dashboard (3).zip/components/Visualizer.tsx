
import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  analyser: AnalyserNode | null;
  isRecording: boolean;
}

const Visualizer: React.FC<VisualizerProps> = ({ analyser, isRecording }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current || !analyser) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      if (!isRecording) {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
         ctx.strokeStyle = '#00ffff11';
         ctx.lineWidth = 1;
         ctx.beginPath();
         ctx.moveTo(0, canvas.height / 2);
         ctx.lineTo(canvas.width, canvas.height / 2);
         ctx.stroke();
         return;
      }
      
      requestAnimationFrame(draw);
      analyser.getByteTimeDomainData(dataArray);

      ctx.fillStyle = 'rgba(5, 5, 5, 0.3)'; 
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.lineWidth = 3;
      ctx.strokeStyle = '#00ffff';
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#00ffff';

      ctx.beginPath();
      const sliceWidth = canvas.width * 1.0 / bufferLength;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        // High-sensitivity mapping
        const v = dataArray[i] / 128.0;
        const y = v * canvas.height / 2;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }

        x += sliceWidth;
      }

      ctx.lineTo(canvas.width, canvas.height / 2);
      ctx.stroke();

      // Peak Indicators
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#00ffff11';
      for(let i=0; i<15; i++) {
        const h = (Math.random() * 80) + 20;
        ctx.fillRect(i * (canvas.width / 15), canvas.height - h, 4, h);
      }
    };

    draw();
  }, [analyser, isRecording]);

  return (
    <div className="relative w-full h-56 rounded-3xl overflow-hidden bg-black/80 border border-white/5 shadow-inner">
      <div className="absolute top-4 left-6 flex items-center gap-3">
         <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></div>
         <span className="text-[10px] font-mono text-cyan-400 font-black tracking-[0.4em] uppercase">Spectral_Ingest_Buffer_v4</span>
      </div>
      <canvas ref={canvasRef} className="w-full h-full" width={1000} height={300} />
      <div className="absolute bottom-4 right-6 text-[8px] font-mono text-gray-600 uppercase tracking-widest">Sampling_Rate: 44.1kHz // FFT: 4096</div>
    </div>
  );
};

export default Visualizer;
